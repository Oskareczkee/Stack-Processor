﻿// Stack Processor.h: plik dołączany dla standardowych systemowych plików dołączanych,
// lub pliki dołączane specyficzne dla projektu.

#pragma once

#include <iostream>
#include "data_structures/dynamic_array.h"
#include "data_structures/dynamic_stack.h"
#include "stack_processor/stack_processor.h"

// TODO: W tym miejscu przywołaj dodatkowe nagłówki wymagane przez program.
